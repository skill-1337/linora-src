# Linora
This is an old version of Linora I have decided to leak it after 12 year old paster italian boy Android pasted the shit out of it

# Evidence
Android is a 11-12 year old paster who can't code for shit, always pastes and gets help from his indian paster friend
homeless, I left linora and gave him ownership so he can continue it (I didn't want to be involved in his paste anymore)
Then he calls me an exit scammer even tho I gave him everything needed that he can continue it, such a femboy faggot
https://cdn.discordapp.com/attachments/872155067116027964/872446043000807474/unknown.png
https://media.discordapp.net/attachments/734429282733916283/872446298463272970/unknown.png
https://media.discordapp.net/attachments/872155067116027964/872446371498721351/unknown.png
https://media.discordapp.net/attachments/734429282733916283/872446937536802856/unknown.png
https://cdn.discordapp.com/attachments/734429282733916283/872447765182025728/unknown.png
https://cdn.discordapp.com/attachments/734429282733916283/872448389705502730/unknown.png
The only reason I left because android was pasting so much i didn't want to be involved.
https://cdn.discordapp.com/attachments/872149235599040522/872189913255264306/unknown.png
He deleted every licenese from keyauth login which I gave him, such a good and mature owner isn't he?
